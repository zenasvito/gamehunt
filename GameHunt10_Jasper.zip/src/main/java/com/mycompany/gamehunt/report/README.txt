Letakkan file game_hunt.jrxml (hasil desain Jasper Studio) di folder/paket ini:
com.mycompany.gamehunt.report  ->  game_hunt.jrxml

Nama file harus persis: game_hunt.jrxml
Program membaca file ini lewat LaporanController, lalu mengisinya dengan koneksi PostgreSQL
(query di dalam jrxml dijalankan langsung ke database gamehunt).
